package com.intelligrape.multiSelect

import org.springframework.web.servlet.support.RequestContextUtils as RCU
import org.codehaus.groovy.grails.commons.DomainClassArtefactHandler

class MultiSelectTagLib {
    static namespace = "ui"

    def multiSelect1 = {attrs ->
        if (!attrs.containsKey('name'))
            throwTagError("Tag [multiSelect] is missing required attribute [name]")
        if (!attrs.containsKey('from'))
            throwTagError("Tag [multiSelect] is missing required attribute [from]")

        String name = attrs.remove('name')
        def remainingList = attrs.remove('from')
        def selectedList = attrs.remove('value')
        def onchange = attrs.remove('onchange') ?: ''
        def cssStyle = attrs.remove('style') ?: ''
        def cssClass = attrs.remove('class') ?: ''
        Map noSelection = attrs.remove('noSelection')
        remainingList = remainingList - [selectedList].flatten()
        out << g.render('template': '/multiSelect/multiSelect', 'plugin': 'multiSelect',
                model: ['name': name,
                        'remainingList': remainingList,
                        'selectedList': selectedList,
                        'onchange': onchange,
                        'cssStyle': cssStyle,
                        'cssClass': cssClass,
                        'noSelection': noSelection
                ])
    }

    def resources = {
//        out << "<style type='text/css'>@import url(${createLinkTo(dir: pluginContextPath, file: 'css/multi.select.css')});</style>"
        out<<"""<link rel="stylesheet" href="${createLinkTo(dir: pluginContextPath, file: 'css/multi.select.css')}"/>"""
        out << """<script type="text/javascript" src="${createLinkTo(dir: pluginContextPath, file: 'js/multi.select.js')}"></script>"""
    }
    def multiSelect = {attrs ->
        def writer = out
        def value = attrs.value
        def multiple = attrs.remove('multiple')

        if (value instanceof Collection && multiple == null) {
            multiple = 'multiple'
        }

        if (!multiple) {
            writer << g.select(attrs)
            return
        }

        def disabled = attrs.remove('disabled')
        attrs.remove('value')

        Boolean isLeftAligned = Boolean.valueOf(attrs.remove('isLeftAligned'))
        String ulClass = isLeftAligned ? "selected-items-left-aligned" : "selected-items"
        def name = attrs.get('name')
        def keys = attrs.get('keys')
        def optionKey = attrs.get('optionKey')
        def optionValue = attrs.get('optionValue')
        def valueMessagePrefix = attrs.get('valueMessagePrefix')
        def messageSource = grailsAttributes.getApplicationContext().getBean("messageSource")
        def locale = RCU.getLocale(request)

        def remainingList = attrs.from - value
        attrs.from = remainingList
        attrs.name = "${attrs.name}-select"

//        writer << """ <div id="${name}-div" class="selected-items"> """
        writer << g.select(attrs)

        writer << """<ul id="${name}-ul" class="${ulClass}">"""
        if (value) {
            value.eachWithIndex {el, i ->
                def keyValue = null
                def displayValue = null
                if (keys) {
                    keyValue = keys[i]
                }
                else if (optionKey) {
                    if (optionKey instanceof Closure) {
                        keyValue = optionKey(el)
                    }
                    else if (el != null && optionKey == 'id' && grailsApplication.getArtefact(DomainClassArtefactHandler.TYPE, el.getClass().name)) {
                        keyValue = el.ident()
                    }
                    else {
                        keyValue = el[optionKey]
                    }
                }
                else {
                    keyValue = el
                }
                if (optionValue) {
                    if (optionValue instanceof Closure) {
                        displayValue = optionValue(el).toString().encodeAsHTML()
                    }
                    else {
                        displayValue = el[optionValue].toString().encodeAsHTML()
                    }
                }
                else if (valueMessagePrefix) {
                    def message = messageSource.getMessage("${valueMessagePrefix}.${keyValue}", null, null, locale)
                    if (message != null) {
                        displayValue = message.encodeAsHTML()
                    }
                    else if (keyValue) {
                        displayValue = keyValue.encodeAsHTML()
                    }
                    else {
                        def s = el.toString()
                        if (s) displayValue = s.encodeAsHTML()
                    }
                }
                else {
                    def s = el.toString()
                    if (s) displayValue = s.encodeAsHTML()
                }

                writer.println()
                writer << "<li>"
                writer << g.hiddenField(name: name, value: keyValue)
                if (isLeftAligned) {
                    writer << """<a href='#'><img src="${resource(dir: 'images', file: 'cross.gif')}" border="0"/></a>"""
                    writer << displayValue
                } else {
                    writer << displayValue
                    writer << """<a href='#'>&nbsp;</a>"""
                }
                writer << "</li>"

            }
        }

        writer << "</ul>"
        writer << """
        <script type="text/javascript">
        jQuery(document).ready(function() {
            jQuery("#${name}-select").bind("change", function() {
                updateSelectBox("${name}", "${isLeftAligned}");
            });
           """
        if (Boolean.valueOf(disabled)) {
            out << """ disableMultiSelect("${name}"); """
        } else {
            out << """ enableMultiSelect("${name}"); """
        }
        writer << "});"
        writer << "</script>"
//        writer << "\n</div>"
    }

}
