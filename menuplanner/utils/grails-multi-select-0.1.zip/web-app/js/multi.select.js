function getNewSelectedElementText(fieldName, fieldValue, displayText, isLeftAligned) {
    var str = "";
    if (isLeftAligned) {
        str = '<li><input type="hidden" name="' + fieldName + '" value="' + fieldValue + '"/> <a href="#"><image src="../images/cross.gif" border="0" /></a>'
                + displayText + ' </li>';
    } else {
        str = '<li><input type="hidden" name="'
                + fieldName + '" value="' + fieldValue + '"/>' + displayText + '<a href="#">&nbsp;</a> </li>';
    }
    return str;
}

function removeMe(image) {
    var liElement = jQuery(image).parent('li');
    var optionText = jQuery.trim(liElement.text());
    var optionValue = jQuery(image).siblings('input:hidden').val();
    var selectElement = jQuery(image).parent('li').parent('ul').siblings('select')[0];
    selectElement.options[selectElement.length] = new Option(optionText, optionValue, false, false);
    liElement.remove();
    return false;
}

function updateSelectBox(multiSelectId, isLeftAligned) {
    isLeftAligned = (isLeftAligned == "true");
    var v = jQuery('#' + multiSelectId + '-select').val();
    if (v.length < 1) return;
    var t = jQuery('#' + multiSelectId + '-select option:selected').text();
    jQuery('#' + multiSelectId + '-ul').append(getNewSelectedElementText(multiSelectId, v, t, isLeftAligned));
    jQuery('#' + multiSelectId + '-select option[value=' + v + ']').remove();
    jQuery('#' + multiSelectId + '-ul>li>a:last').click(function() {
        removeMe(this);
    });
}

function disableMultiSelect(multiSelectId) {
        jQuery('#' + multiSelectId + '-ul a').unbind('click');
        jQuery('#' + multiSelectId + '-ul a').removeAttr('href');
        jQuery('#' + multiSelectId + '-ul>li>a>img').css('opacity', '0.2');
        jQuery('#' + multiSelectId + '-select').attr('disabled', true);
}

function enableMultiSelect(multiSelectId) {
        jQuery('#' + multiSelectId + '-ul>li>a').attr('href', '#');
        jQuery('#' + multiSelectId + '-ul>li>a>img').css('opacity', '1');
        jQuery('#' + multiSelectId + '-ul>li>a').bind('click', function() {
            removeMe(this);
        });
        jQuery('#' + multiSelectId + '-select').removeAttr('disabled');
}